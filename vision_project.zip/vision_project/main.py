import cv2
import csv
import os
from datetime import datetime
from collections import defaultdict

import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

PROTOTXT = os.path.join(BASE_DIR, "deploy.prototxt")
MODEL = os.path.join(BASE_DIR, "MobileNetSSD_deploy.caffemodel")

# Classes from MobileNet SSD
CLASSES = [
    "background", "aeroplane", "bicycle", "bird", "boat",
    "bottle", "bus", "car", "cat", "chair", "cow", "diningtable",
    "dog", "horse", "motorbike", "person", "pottedplant",
    "sheep", "sofa", "train", "tvmonitor"
]

def draw_confidence_bar(frame, confidence, x=10, y=60, width=200, height=20):
    conf = int(confidence * 100)
    bar_fill = int(width * confidence)

    cv2.rectangle(frame, (x, y), (x + width, y + height), (255, 255, 255), 2)
    cv2.rectangle(frame, (x, y), (x + bar_fill, y + height), (0, 255, 0), -1)
    cv2.putText(frame, f"{conf}%", (x + width + 10, y + height),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

def main():

    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Error: no se pudo abrir la cámara")
        return

    os.makedirs("Detected_Objects", exist_ok=True)
    csv_file = "Detected_Objects/labels.csv"

    if not os.path.isfile(csv_file):
        with open(csv_file, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["Timestamp", "Label"])

    last_label = None
    object_counter = defaultdict(int)

    stable_label = None
    stable_frames = 0
    REQUIRED_STABLE_FRAMES = 5

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        h, w = frame.shape[:2]

        # --- DNN input ---
        blob = cv2.dnn.blobFromImage(
            cv2.resize(frame, (300, 300)),
            0.007843,
            (300, 300),
            127.5
        )
        net.setInput(blob)
        detections = net.forward()

        best_conf = 0
        best_label = None

        # --- Pick strongest detection ---
        for i in range(detections.shape[2]):
            confidence = detections[0, 0, i, 2]

            if confidence > 0.5 and confidence > best_conf:
                idx = int(detections[0, 0, i, 1])
                best_label = CLASSES[idx]
                best_conf = confidence

        # --- Stable detection logic ---
        if best_label == stable_label:
            stable_frames += 1
        else:
            stable_label = best_label
            stable_frames = 1

        if stable_frames >= REQUIRED_STABLE_FRAMES:
            last_label = stable_label

        # --- Draw detection ---
        if last_label:
            cv2.putText(frame, f"{last_label}", (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            draw_confidence_bar(frame, best_conf)

        # --- Draw object counter ---
        y_offset = 100
        cv2.putText(frame, "Detected:", (10, y_offset),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2)

        for obj, count in object_counter.items():
            y_offset += 30
            cv2.putText(frame, f"{obj}: {count}", (10, y_offset),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)

        cv2.imshow("Object Detection", frame)

        key = cv2.waitKey(1) & 0xFF

        # --- Save to CSV ---
        if key == ord(" "):
            if last_label:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                object_counter[last_label] += 1

                with open(csv_file, "a", newline="") as f:
                    writer = csv.writer(f)
                    writer.writerow([timestamp, last_label])

                print(f"Guardado: {last_label}")

            else:
                print("No hay objeto detectado para guardar.")

        if key == ord("q"):
            break

    cap.release()
    cv2.destroyAllWindows()