import os
import sys
import subprocess

def run_script(script_name):
    # Detecta automáticamente la carpeta donde está este archivo
    base_dir = os.path.dirname(os.path.abspath(__file__))
    script_path = os.path.join(base_dir, script_name)

    if not os.path.exists(script_path):
        print(f"ERROR: Script not found -> {script_path}")
        return
    
    # Usa el mismo intérprete con el que ejecutas runner.py
    python_exec = sys.executable
    subprocess.run([python_exec, script_path])

def main():
    print("===================================")
    print("     Object Detection Project")
    print("===================================")
    print("Choose a mode:")
    print("1. Detection mode (main.py)")
    print("2. Dataset Builder (dataset_builder.py)")
    print("q. Quit")
    print("===================================")

    choice = input("Select option: ").strip()

    if choice == "1":
        run_script("main.py")
    elif choice == "2":
        run_script("dataset_builder.py")
    elif choice.lower() == "q":
        print("Exiting program.")
    else:
        print("Invalid option. Try again.")

if __name__ == "__main__":
    main()
